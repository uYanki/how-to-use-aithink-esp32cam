/*
 * qr_recoginize.h
 *
 *  Created on: 2017年12月31日
 *      Author: sky
 */

#ifndef MAIN_QR_RECOGINIZE_H_
#define MAIN_QR_RECOGINIZE_H_

enum{
	RECONGIZE_OK,
	RECONGIZE_FAIL
};

void qr_recoginze(void *pdata);
//int qr_recoginze() ;

#endif /* MAIN_QR_RECOGINIZE_H_ */
