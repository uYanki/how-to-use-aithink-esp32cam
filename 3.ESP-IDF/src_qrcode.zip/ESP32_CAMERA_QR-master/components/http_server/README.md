Simple HTTP server
------------------

This is a very minimal HTTP server I use in some of the projects.

Absolutely not ready for any kind of production use.

How to use
----------

Really, please see above note.

This directory is an ESP-IDF component. Clone it (or add it as a submodule) into the component directory of the project.


Documentation
-------------

None yet, but I tried to make the comments in the header file helpful.


Example
-------

None yet.


Debugging
---------

Increasing log level to "Verbose" should produce lots of output related to request handling.


License
-------

GPL, see [LICENSE](LICENSE) file. Mostly because this is a very early version. Will be relicensed as something more reasonable later.

