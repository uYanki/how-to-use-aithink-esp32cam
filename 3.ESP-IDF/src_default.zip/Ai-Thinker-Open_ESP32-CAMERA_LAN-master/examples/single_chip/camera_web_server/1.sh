#!/bin/bash

make -j8

make flash
